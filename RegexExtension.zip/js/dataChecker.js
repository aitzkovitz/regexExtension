// function to check whether date are behind
function dateChecker(dateString){
	new Date();
	// compare current date to parsed date
}

function phoneNumberChecker(){

}

function emailFormatChecker(){
	// check if 'email' and 'e-mail' are used 

}

// data formats that may be seen:
/*
* 10/19/1994
* 01/15/1994
* 1/5/1975
* May 5th, 2017
* ...
*
*
*
*
*
*
*
*
*/